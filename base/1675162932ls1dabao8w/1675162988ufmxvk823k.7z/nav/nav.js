function create_menu(basepath)
{
	var base = (basepath == 'null') ? '' : basepath;

	document.write(
		'<table cellpadding="0" cellspaceing="0" border="0" style="width:98%"><tr>' +
		'<td class="td" valign="top">' +

		'<ul>' +
		'<li><a href="'+base+'index.html">Главная страница</a></li>' +
		'<li><a href="'+base+'toc.html">Содержание</a></li>' +
		'</ul>' +

		'<h3>Основная информация</h3>' +
		'<ul>' +
			'<li><a href="'+base+'general/requirements.html">Требования к серверу</a></li>' +
			'<li><a href="'+base+'license.html">Лицензионное соглашение</a></li>' +
			'<li><a href="'+base+'changelog.html">Список изменений</a></li>' +
			'<li><a href="'+base+'general/credits.html">Кредиты</a></li>' +
		'</ul>' +

		'<h3>Установка</h3>' +
		'<ul>' +
			'<li><a href="'+base+'installation/downloads.html">Загрузка CodeIgniter</a></li>' +
			'<li><a href="'+base+'installation/index.html">Инструкции по установке</a></li>' +
			'<li><a href="'+base+'installation/upgrading.html">Обновление из предыдущих версий</a></li>' +
			'<li><a href="'+base+'installation/troubleshooting.html">Устранение ошибок</a></li>' +
		'</ul>' +

		'<h3>Введение</h3>' +
		'<ul>' +
			'<li><a href="'+base+'overview/getting_started.html">Начало</a></li>' +
			'<li><a href="'+base+'overview/at_a_glance.html">CodeIgniter в глянце</a></li>' +
			'<li><a href="'+base+'overview/cheatsheets.html">Шпаргалки по CodeIgniter</a></li>' +
			'<li><a href="'+base+'overview/features.html">Опции</a></li>' +
			'<li><a href="'+base+'overview/appflow.html">Ход выполнения приложения</a></li>' +
			'<li><a href="'+base+'overview/mvc.html">Model-View-Controller</a></li>' +
			'<li><a href="'+base+'overview/goals.html">Архитектурные цели</a></li>' +
		'</ul>' +
		
		'<h3>Учебник</h3>' +
		'<ul>' +
			'<li><a href="'+base+'tutorial/index.html">Введение</a></li>' +
			'<li><a href="'+base+'tutorial/static_pages.html">Статичные страницы</a></li>' +
			'<li><a href="'+base+'tutorial/news_section.html">Разделы новостей</a></li>' +
			'<li><a href="'+base+'tutorial/create_news_items.html">Создание новых элементов</a></li>' +
			'<li><a href="'+base+'tutorial/conclusion.html">Заключение</a></li>' +
		'</ul>' +
		
		'</td><td class="td_sep" valign="top">' +

		'<h3>Основные темы</h3>' +
		'<ul>' +
			'<li><a href="'+base+'general/urls.html">URLы CodeIgniter</a></li>' +
			'<li><a href="'+base+'general/controllers.html">Контроллеры</a></li>' +
			'<li><a href="'+base+'general/reserved_names.html">Зарезервированные имена</a></li>' +
			'<li><a href="'+base+'general/views.html">Отображения</a></li>' +
			'<li><a href="'+base+'general/models.html">Модели</a></li>' +
			'<li><a href="'+base+'general/helpers.html">Помощники</a></li>' +
			'<li><a href="'+base+'general/libraries.html">Использование библиотек CodeIgniter</a></li>' +
			'<li><a href="'+base+'general/creating_libraries.html">Создание собственных библиотек</a></li>' +
			'<li><a href="'+base+'general/drivers.html">Использование драйверов CodeIgniter</a></li>' +
			'<li><a href="'+base+'general/creating_drivers.html">Создание собственных драйверов</a></li>' +
			'<li><a href="'+base+'general/core_classes.html">Создание классов ядра</a></li>' +
			'<li><a href="'+base+'general/hooks.html">Хуки - расширение ядра</a></li>' +
			'<li><a href="'+base+'general/autoloader.html">Автозагрузка ресурсов</a></li>' +
			'<li><a href="'+base+'general/common_functions.html">Общие функции</a></li>' +
			'<li><a href="'+base+'general/routing.html">URI-роутинг</a></li>' +
			'<li><a href="'+base+'general/errors.html">Обработка ошибок</a></li>' +
			'<li><a href="'+base+'general/caching.html">Кеширование</a></li>' +
			'<li><a href="'+base+'general/profiling.html">Профилирование приложения</a></li>' +
			'<li><a href="'+base+'general/cli.html">Запуск через командную строку (CLI)</a></li>' +
			'<li><a href="'+base+'general/managing_apps.html">Управление приложениями</a></li>' +
			'<li><a href="'+base+'general/environments.html">Управление окружениями</a></li>' +
			'<li><a href="'+base+'general/alternative_php.html">Альтернативный синтаксис PHP</a></li>' +
			'<li><a href="'+base+'general/security.html">Безопасность</a></li>' +
			'<li><a href="'+base+'general/styleguide.html">Руководство по стилю PHP</a></li>' +
			'<li><a href="'+base+'doc_style/index.html">Написание документации</a></li>' +
		'</ul>' +

		'<h3>Дополнительные ресурсы</h3>' +
		'<ul>' +
		'<li><a href="http://codeigniter.com/forums/" target="_blank">Community Forums</a></li>' +
		'<li><a href="http://codeigniter.com/wiki/" target="_blank">Community Wiki</a></li>' +
		'<li><a href="http://code-igniter.ru/" target="_blank">Русскоязычное сообщество</a></li>' +
		'</ul>' +

		'</td><td class="td_sep" valign="top">' +

		'<h3>Справка по классам</h3>' +
		'<ul>' +
		'<li><a href="'+base+'libraries/benchmark.html">Benchmarking</a></li>' +
		'<li><a href="'+base+'libraries/calendar.html">Calendar</a></li>' +
		'<li><a href="'+base+'libraries/cart.html">Cart</a></li>' +
		'<li><a href="'+base+'libraries/config.html">Config</a></li>' +
		'<li><a href="'+base+'libraries/email.html">Email</a></li>' +
		'<li><a href="'+base+'libraries/encryption.html">Encryption</a></li>' +
		'<li><a href="'+base+'libraries/file_uploading.html">File Uploading</a></li>' +
		'<li><a href="'+base+'libraries/form_validation.html">Form Validation</a></li>' +
		'<li><a href="'+base+'libraries/ftp.html">FTP</a></li>' +
		'<li><a href="'+base+'libraries/table.html">HTML Table</a></li>' +
		'<li><a href="'+base+'libraries/image_lib.html">Image Manipulation</a></li>' +
		'<li><a href="'+base+'libraries/input.html">Input</a></li>' +
		'<li><a href="'+base+'libraries/javascript.html">Javascript</a></li>' +
		'<li><a href="'+base+'libraries/loader.html">Loader</a></li>' +
		'<li><a href="'+base+'libraries/language.html">Language</a></li>' +
		'<li><a href="'+base+'libraries/migration.html">Migration</a></li>' +
		'<li><a href="'+base+'libraries/output.html">Output</a></li>' +
		'<li><a href="'+base+'libraries/pagination.html">Pagination</a></li>' +
		'<li><a href="'+base+'libraries/security.html">Security</a></li>' +
		'<li><a href="'+base+'libraries/sessions.html">Session</a></li>' +
		'<li><a href="'+base+'libraries/trackback.html">Trackback</a></li>' +
		'<li><a href="'+base+'libraries/parser.html">Template Parser</a></li>' +
		'<li><a href="'+base+'libraries/typography.html">Typography</a></li>' +
		'<li><a href="'+base+'libraries/unit_testing.html">Unit Testing</a></li>' +
		'<li><a href="'+base+'libraries/uri.html">URI</a></li>' +
		'<li><a href="'+base+'libraries/user_agent.html">User Agent</a></li>' +
		'<li><a href="'+base+'libraries/xmlrpc.html">XML-RPC</a></li>' +
		'<li><a href="'+base+'libraries/zip.html">Zip Encoding</a></li>' +
		'</ul>' +

		'</td><td class="td_sep" valign="top">' +

		'<h3>Справка по драйверам</h3>' +
		'<ul>' +
		'<li><a href="'+base+'libraries/caching.html">Кеширование</a></li>' +
		'<li><a href="'+base+'database/index.html">База данных</a></li>' +
		'<li><a href="'+base+'libraries/javascript.html">Javascript</a></li>' +
		'</ul>' +

		'<h3>Справка по помощникам</h3>' +
		'<ul>' +
		'<li><a href="'+base+'helpers/array_helper.html">Array</a></li>' +
		'<li><a href="'+base+'helpers/captcha_helper.html">CAPTCHA</a></li>' +
		'<li><a href="'+base+'helpers/cookie_helper.html">Cookie</a></li>' +
		'<li><a href="'+base+'helpers/date_helper.html">Date</a></li>' +
		'<li><a href="'+base+'helpers/directory_helper.html">Directory</a></li>' +
		'<li><a href="'+base+'helpers/download_helper.html">Download</a></li>' +
		'<li><a href="'+base+'helpers/email_helper.html">Email</a></li>' +
		'<li><a href="'+base+'helpers/file_helper.html">File</a></li>' +
		'<li><a href="'+base+'helpers/form_helper.html">Form</a></li>' +
		'<li><a href="'+base+'helpers/html_helper.html">HTML</a></li>' +
		'<li><a href="'+base+'helpers/inflector_helper.html">Inflector</a></li>' +
		'<li><a href="'+base+'helpers/language_helper.html">Language</a></li>' +
		'<li><a href="'+base+'helpers/number_helper.html">Number</a></li>' +
		'<li><a href="'+base+'helpers/path_helper.html">Path</a></li>' +
		'<li><a href="'+base+'helpers/security_helper.html">Security</a></li>' +
		'<li><a href="'+base+'helpers/smiley_helper.html">Smiley</a></li>' +
		'<li><a href="'+base+'helpers/string_helper.html">String</a></li>' +
		'<li><a href="'+base+'helpers/text_helper.html">Text</a></li>' +
		'<li><a href="'+base+'helpers/typography_helper.html">Typography</a></li>' +
		'<li><a href="'+base+'helpers/url_helper.html">URL</a></li>' +
		'<li><a href="'+base+'helpers/xml_helper.html">XML</a></li>' +
		'</ul>' +

		'</td></tr></table>');
}
