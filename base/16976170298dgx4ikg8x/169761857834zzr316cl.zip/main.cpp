#include <QDebug>
#include "math_parser.h"

int main(int argc, char *argv[])
{
    Q_UNUSED(argc)
    Q_UNUSED(argv)

    QMap<QString, QString> constants;
    constants["pi"]="3.1415";
    constants["ten"]="10";
    constants["ourConstanta"]="25+ten";

    MathParser mathParser;
    mathParser.setConstantsTable( constants );


    float result1=mathParser.calculate("1+pi+ten+ourConstanta");
    if(!mathParser.isCalculateError())
    {
        qDebug() << "Result 1: " << result1;
    }
    else
    {
        qDebug() << "Error at expression 1 parse";
    }


    float result2=mathParser.calculate("2+incorrectConstanta");
    if(!mathParser.isCalculateError())
    {
        qDebug() << "Result 2: " << result2;
    }
    else
    {
        qDebug() << "Error at expression 2 parse";
    }

}
