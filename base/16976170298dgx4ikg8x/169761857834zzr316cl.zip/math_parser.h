#include <algorithm>
#include <iostream>
#include <string>
#include <cctype>
#include <iterator>

#include <QString>
#include <QMap>
#include <QHash>

using namespace std;


class MathParser
{

public:
    MathParser();
    virtual ~MathParser();

    bool setConstantsTable( QMap<QString, QString> constantsTable );
    float calculate(const QString &text);

    bool isCalculateError();

private:

    float constantCalculate(const QString &text);
    QString createDirectPolkaNote(const QString &text);
    float calculateByDirectPolkaNote(QString polkaNote, bool isConstantCalculate);

    bool m_isCalculateError=false;
    QHash<QString, float> m_constantsTable;
};


// Представление математического выражения в виде дерева
class Exp
{

public:

    Exp(){}
    virtual ~Exp(){}

    virtual string print(){ return ""; }
    virtual void release(){}

    static Exp* strToExp(string &str); // Построитель абстрактного дерева из строки
};


// Конечный элемент абстрактного дерева
class Term : public Exp
{
public:

    Term(string v) : val(v){}

    string print();
    void release(){}

private:

    string val;
};


// Узел абстрактного дерева
class Node : public Exp
{
public:

    Node(char op, Exp* left, Exp* right) : op(op), l_exp(left), r_exp(right){}
    ~Node(){}

    string print();
    void release();

private:

    char op; // Возможные значения +, -, *, /
    Exp *l_exp;
    Exp *r_exp;
};
